# Databricks notebook source
# MAGIC %md
# MAGIC # Create Fact Tables
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Reading Silver Data**

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC SELECT * FROM PARQUET.`abfss://silver@carranadatalake.dfs.core.windows.net/carsales`

# COMMAND ----------

df_silver = spark.sql('''  
                      SELECT * FROM PARQUET.`abfss://silver@carranadatalake.dfs.core.windows.net/carsales`
                      ''')

# COMMAND ----------

df_model = spark.sql('''  
                      SELECT * FROM cars_catalog.gold.dim_model
                    ''')
df_branch = spark.sql('''  
                       SELECT * FROM cars_catalog.gold.dim_branch
                    ''')
df_dealer = spark.sql('''  
                        SELECT * FROM cars_catalog.gold.dim_dealer
                    ''')
df_date = spark.sql('''  
                       SELECT * FROM cars_catalog.gold.dim_date
''')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(DISTINCT Dealer_ID) FROM cars_catalog.gold.dim_dealer

# COMMAND ----------

display(df_model)

# COMMAND ----------

df_fact = df_silver.join(df_model, df_silver.Model_ID == df_model.Model_ID, 'left') \
               .join(df_branch, df_silver.Branch_ID == df_branch.Branch_ID, 'left') \
               .join(df_dealer, df_silver.Dealer_ID ==  df_dealer.Dealer_ID, 'left') \
               .select('Units_Sold', 'RevperUnit',  'dim_model_key', 'dim_branch_key', 'dim_dealer_key')
                   
              # .join(df_date, df_silver.Date_ID == df_date.Date_ID, 'left') \
               

# COMMAND ----------

display(df_fact)

# COMMAND ----------

df_fact.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing Fact Table
# MAGIC

# COMMAND ----------

from delta import DeltaTable


# COMMAND ----------

if spark.catalog.tableExists("cars_catalog.gold.factsales"):
    delta_table = DeltaTable.forPath(spark, "abfss://gold@carranadatalake.dfs.core.windows.net/factsales")

    delta_table.alias("trg").merge(df_fact.alias("src"), "trg.dim_date_key = src.dim_date_key AND trg.dim_model_key = src.dim_model_key AND trg.dim_dealer_key = src.dim_dealer_key AND trg.dim_branch_key = src.dim_branch_key") \
                                    .whenMatchedUpdateAll() \
                                    .whenNotMatchedInsertAll() \
                                    .execute()
                                    
else:
    df_fact.write.format("delta").mode("overwrite").option("path", "abfss://gold@carranadatalake.dfs.core.windows.net/factsales") \
    .saveAsTable("cars_catalog.gold.factsales")
 



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM cars_catalog.gold.factsales

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) FROM cars_catalog.gold.factsales

# COMMAND ----------


# Databricks notebook source
df = spark.read.format("parquet") \
     .option("inferSchema", "true") \
     .load("abfss://bronze@carranadatalake.dfs.core.windows.net/Raw_Data/")


# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Transformation

# COMMAND ----------

from pyspark.sql.functions import col, lit, split,sum
from pyspark.sql.types import StringType, IntegerType, DoubleType, StructType, StructField

# COMMAND ----------

df = df.withColumn("Model_Category", split(col('Model_ID'),'-')[0]) \
    .withColumn("Units_Sold", col("Units_Sold").cast(StringType()))  \
    .withColumn("Units_Sold", col("Units_Sold").cast(IntegerType()))

# COMMAND ----------

display(df)


# COMMAND ----------

df = df.withColumn("RevperUnit", col("Revenue")/col("Units_Sold"))
display(df)


# COMMAND ----------

# MAGIC %md
# MAGIC # AD-HoC

# COMMAND ----------

df1 = df.groupBy("year", "Model_Category").agg(sum("Units_Sold").alias("Total_Revenue")).sort("Year", "Total_Revenue", ascending=[1,0])
display(df1)

# COMMAND ----------

df.write.mode('overwrite').format('parquet').option('path', 'abfss://silver@carranadatalake.dfs.core.windows.net/carsales').save()

# COMMAND ----------


# Databricks notebook source
if spark.catalog.tableExists('cars_catalog.gold.dim_model'):
    spark.sql(''' drop table cars_catalog.gold.dim_model  ''')
    print("Hello Rana")
else:
    print("Hello Munni")

# COMMAND ----------


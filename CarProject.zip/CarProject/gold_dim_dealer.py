# Databricks notebook source
# MAGIC %md
# MAGIC # Create Incremental Flag
# MAGIC

# COMMAND ----------

dbutils.widgets.text('incremental_flag', '0')


# COMMAND ----------

incremental_flag = dbutils.widgets.get('incremental_flag')
print(incremental_flag)


# COMMAND ----------

# MAGIC %md 
# MAGIC Create Dimention Model

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM PARQUET.`abfss://silver@carranadatalake.dfs.core.windows.net/carsales`

# COMMAND ----------

df_src = spark.sql('''
                   SELECT * FROM PARQUET.`abfss://silver@carranadatalake.dfs.core.windows.net/carsales`
                ''')

# COMMAND ----------

display(df_src)

# COMMAND ----------

if spark.catalog.tableExists('cars_catalog.gold.dim_dealer'):
  df_sink = spark.sql('''
                       SELECT dim_dealer_key, Dealer_ID, DealerName
                         FROM cars_catalog.gold.dim_dealer
                    ''')
else:
  df_sink = spark.sql('''
                       SELECT 1 AS dim_dealer_key, Dealer_ID, DealerName
                         FROM PARQUET.`abfss://silver@carranadatalake.dfs.core.windows.net/carsales`
                        WHERE 1 = 0
                    ''')


# COMMAND ----------

display(df_sink)

# COMMAND ----------

# MAGIC %md 
# MAGIC # Filtering New records and Old records

# COMMAND ----------

df_filter = df_src.join(df_sink, on=df_src.Dealer_ID == df_sink.Dealer_ID, how='left').select(df_sink.dim_dealer_key, df_src.Dealer_ID, df_src.DealerName)

# COMMAND ----------

display(df_filter)

# COMMAND ----------

from pyspark.sql.functions import col, monotonically_increasing_id

# COMMAND ----------


df_filter_old = df_filter.filter(col('dim_dealer_key').isNotNull())

# COMMAND ----------

df_filter_new = df_filter.filter(col('dim_dealer_key').isNull())

# COMMAND ----------

df_filter_new = df_filter_new.distinct().select("Dealer_ID", "DealerName")

# COMMAND ----------

display(df_filter_new)

# COMMAND ----------

# MAGIC %md
# MAGIC # Create Surrogate Key

# COMMAND ----------

# MAGIC %md
# MAGIC **Fetch the max surrogate the key from existing table**

# COMMAND ----------

if(incremental_flag == '0'):
    max_value = 0
else:
    max_value_df = spark.sql('''  SELECT MAX(dim_dealer_key) FROM cars_catalog.gold.dim_model  ''')
    max_value = max_value_df.collect()[0][0]
    

# COMMAND ----------

# MAGIC %md 
# MAGIC # Create Surrogate Key Column and ADD the max surrogate key

# COMMAND ----------

df_filter_new = df_filter_new.withColumn('dim_dealer_key', max_value + monotonically_increasing_id()+ 1)

# COMMAND ----------

display(df_filter_new)

# COMMAND ----------

df_filter_new = df_filter_new.select("dim_dealer_key", "Dealer_ID", "DealerName")

# COMMAND ----------

display(df_filter_new)

# COMMAND ----------

# MAGIC %md 
# MAGIC Create Final DF -df_filter_old + df_filter_new

# COMMAND ----------

df_final = df_filter_old.union(df_filter_new)

# COMMAND ----------

display(df_final)

# COMMAND ----------

# MAGIC %md
# MAGIC SCD TYPE 1 (UPSERT)

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

# Incremental Load
if spark.catalog.tableExists('cars_catalog.gold.dim_dealer'):
    detla_table = DelataTable.forPath(spark, "abfss://gold@carranadatalake.dfs.core.windows.net/dim_dealer")

    detla_table.alias('trg').merge(df_final.alias('src'), 'trg.dim_dealer_key == src.dim_dealer_key') \
        .whenMatchedUpdateAll() \
        .whenNotMatchedInsertAll() \
        .execute()
else:
    df_final.write.format('delta') \
        .mode('overwrite') \
        .option("path", "abfss://gold@carranadatalake.dfs.core.windows.net/dim_dealer") \
        .saveAsTable('cars_catalog.gold.dim_dealer')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT  * FROM cars_catalog.gold.dim_dealer

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT  COUNT(DISTINCT Dealer_ID) FROM cars_catalog.gold.dim_dealer

# COMMAND ----------


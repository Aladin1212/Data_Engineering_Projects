# Databricks notebook source
# MAGIC %md
# MAGIC # Create Catalog
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE catalog cars_catalog

# COMMAND ----------

# MAGIC %md 
# MAGIC # Creare Schema 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC create schema cars_catalog.silver;
# MAGIC create schema cars_catalog.gold;

# COMMAND ----------

